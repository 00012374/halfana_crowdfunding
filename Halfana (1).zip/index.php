<?php include('template/common/header.php'); ?>
<!-- Your page content goes here -->
<?php include('template/models/home.php'); ?>
<?php include('template/common/footer.php'); ?>
