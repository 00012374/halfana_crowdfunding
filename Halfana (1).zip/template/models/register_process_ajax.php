<?php
// Include necessary files and configurations
include('../../database/db_config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Your database insertion logic here

    if ($insertionSuccessful) {
        echo "Registration successful!";
    } else {
        echo "Registration failed!";
    }

    // Close database connection if needed
    $conn->close();
}
?>
