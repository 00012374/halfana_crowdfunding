<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');

// Check if the database connection is successful
if (!$pdo) {
    die("Connection failed: " . $pdo->errorInfo()[2]);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert user data into the database
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (:username, :email, :password)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashedPassword); // Store the hashed password

    try {
        $stmt->execute();
        echo "<div class=\"container\" style=\"text-align:center;\">Registration successful! Let's <a href='/login'>login</a> now.</div>";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
