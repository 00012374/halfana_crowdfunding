<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/vendor/autoload.php';
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');

// Set your secret API key
\Stripe\Stripe::setApiKey('sk_test_51OzVIDHvIAytjv5haTO99WZEGrlpu8qHLoNrlTZEEl6T6UjXrpuh9RLsjqtwPVTewHuIA0caNpMEjOdvIwqk5yyV00X8GSHpQX');

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve amount, project ID, and Stripe token from form data
    $amount = $_POST['amount'];
    $project_id = $_POST['project_id'];
    $token = $_POST['stripeToken'];

    try {
        // Create a charge using the token and amount
        $charge = \Stripe\Charge::create([
            'amount' => $amount, // Amount in cents
            'currency' => 'usd',
            'description' => 'Donation', // Description of the charge
            'source' => $token, // Token obtained from the client-side Stripe.js
        ]);

        // Payment successful, update funding_current column in projects table
        $sql = "UPDATE projects SET funding_current = funding_current + :amount WHERE project_id = :project_id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':amount', $amount, PDO::PARAM_INT);
        $stmt->bindParam(':project_id', $project_id, PDO::PARAM_INT);
        $stmt->execute();

        // Redirect to success page
        header("Location: /success");
        exit();
    } catch (\Stripe\Exception\CardException $e) {
        // Handle card errors
        echo "Card Error: " . $e->getError()->message;
        exit();
    } catch (\Stripe\Exception\StripeException $e) {
        // Handle other Stripe errors
        echo "Stripe Error: " . $e->getMessage();
        exit();
    } catch (PDOException $e) {
        // Handle database errors
        echo "Database Error: " . $e->getMessage();
        exit();
    } catch (Exception $e) {
        // Handle other errors
        echo "Error: " . $e->getMessage();
        exit();
    }
} else {
    // Invalid request method
    header("HTTP/1.1 405 Method Not Allowed");
    echo "Invalid request method.";
    exit();
}
?>
