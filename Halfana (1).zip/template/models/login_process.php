<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include necessary files and configurations
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');

function getUserDataFromDatabase($username) {
    global $pdo;

    // Prepare the query to fetch the user ID and hashed password
    $stmt = $pdo->prepare("SELECT user_id, password FROM users WHERE username = ?");
    $stmt->execute([$username]);

    // Fetch the user data
    $userData = $stmt->fetch(PDO::FETCH_ASSOC);
    
    return $userData;
}

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Collect form data
        $username = $_POST['username'];
        $passwordEntered = $_POST['password'];

        // Retrieve user data from the database based on the username
        $userData = getUserDataFromDatabase($username);

        if ($userData && password_verify($passwordEntered, $userData['password'])) {
            // Login successful
            $_SESSION['username'] = $username; // Store username in session
            $_SESSION['user_id'] = $userData['user_id']; // Store user ID in session
            header("Location: user_dashboard");
            exit();
        } else {
            // Incorrect password
            echo "<div class=\"container\" style=\"text-align:center;\">Incorrect username or password! Back to home <a href='/'>home.</a></div>";
        }
    }
} catch (Exception $e) {
    // Log the exception message
    error_log('Exception: ' . $e->getMessage());
    // Print a generic error message for the user
    echo 'An unexpected error occurred. Please try again later.';
}
?>
