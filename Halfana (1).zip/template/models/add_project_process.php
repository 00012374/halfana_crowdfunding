<?php
// Include the database configuration file
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');
session_start(); // Start the session

try {
    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Retrieve form data
        $title = $_POST['title'];
        $description = $_POST['description'];
        $funding_goal = $_POST['funding_goal'];
        $deadline = $_POST['deadline'];
        $category_id = $_POST['category'];
        
        // Get the user_id from the session
        $user_id = $_SESSION['user_id'];

        // Define the directory where uploaded images will be stored
        $uploadDirectory = $_SERVER['DOCUMENT_ROOT'] . '/uploads/';

        // Get the file details from the uploaded file
        $fileName = $_FILES['projectImage']['name'];
        $filePath = $uploadDirectory . $fileName;

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES['projectImage']['tmp_name'], $filePath)) {
            // File was uploaded successfully
            // Now store the file path in the database
            $imagePath = '/uploads/' . $fileName;

            // Prepare the SQL statement
            $stmt = $pdo->prepare("INSERT INTO projects (title, description, funding_goal, deadline, category_id, user_id, image_path) VALUES (:title, :description, :funding_goal, :deadline, :category_id, :user_id, :image_path)");

            // Bind parameters
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':funding_goal', $funding_goal);
            $stmt->bindParam(':deadline', $deadline);
            $stmt->bindParam(':category_id', $category_id);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':image_path', $imagePath);

            // Execute the statement
            $stmt->execute();

            // Redirect the user to a success page or display a success message
            header("Location: /user_dashboard");
            exit();
        } else {
            // Failed to move the uploaded file
            // Handle the error accordingly
            echo "Failed to upload the image.";
        }
    }
} catch (PDOException $e) {
    // Handle database errors
    echo "Connection failed: " . $e->getMessage();
    // You can log the error or display a user-friendly message here
}
?>
