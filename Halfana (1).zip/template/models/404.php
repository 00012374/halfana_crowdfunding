<?php include($_SERVER['DOCUMENT_ROOT'] . '/common/header.php');
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php'); ?>

404