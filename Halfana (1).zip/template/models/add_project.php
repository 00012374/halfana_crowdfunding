<?php include('../common/header.php'); ?>

<form action="add-project-process" method="POST" enctype="multipart/form-data">
    <label for="title">Title:</label>
    <input type="text" id="title" name="title"><br>

    <label for="description">Description:</label><br>
    <textarea id="description" name="description" rows="4" cols="50"></textarea><br>

    <label for="funding_goal">Funding Goal:</label>
    <input type="number" id="funding_goal" name="funding_goal"><br>

    <label for="deadline">Deadline:</label>
    <input type="date" id="deadline" name="deadline"><br>

    <label>Category:</label><br>
    <input type="radio" id="technology" name="category" value="1">
    <label for="technology">Technology</label><br>
    <input type="radio" id="art" name="category" value="2">
    <label for="art">Art</label><br>
    <input type="radio" id="music" name="category" value="3">
    <label for="music">Music</label><br>
    <!-- Add more radio buttons as needed -->

    <div class="form-group">
        <label for="projectImage">Project Image:</label>
        <input type="file" class="form-control-file" id="projectImage" name="projectImage">
    </div><br>

    <input type="submit" value="Submit">
</form>