<?php
session_start();
// Include necessary files and configurations
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve form data
    $project_id = $_POST['project_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $funding_goal = $_POST['funding_goal'];
    $deadline = $_POST['deadline'];
    $category_id = $_POST['category'];
    
    // Get the user_id from the session
    $user_id = $_SESSION['user_id'];

    // Define the directory where uploaded images will be stored
    $uploadDirectory = $_SERVER['DOCUMENT_ROOT'] . '/uploads/';

    // Check if a new image file is uploaded
    if ($_FILES['projectImage']['size'] > 0) {
        // Get the file details from the uploaded file
        $fileName = $_FILES['projectImage']['name'];
        $filePath = $uploadDirectory . $fileName;

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES['projectImage']['tmp_name'], $filePath)) {
            // File was uploaded successfully
            // Now store the file path in the database
            $imagePath = '/uploads/' . $fileName;
        } else {
            // Failed to move the uploaded file
            // Handle the error accordingly
            echo "Failed to upload the image.";
            exit();
        }
    } else {
        // No new image file uploaded, retain the existing image path from the database
        $stmt = $pdo->prepare("SELECT image_path FROM projects WHERE project_id = ?");
        $stmt->execute([$project_id]);
        $existingImagePath = $stmt->fetchColumn();
        $imagePath = $existingImagePath;
    }

    // Prepare the SQL statement to update the project details
    $sql = "UPDATE projects 
            SET title = :title, description = :description, funding_goal = :funding_goal, deadline = :deadline, category_id = :category_id, image_path = :image_path
            WHERE project_id = :project_id AND user_id = :user_id";
    $stmt = $pdo->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':title', $title);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':funding_goal', $funding_goal);
    $stmt->bindParam(':deadline', $deadline);
    $stmt->bindParam(':category_id', $category_id);
    $stmt->bindParam(':image_path', $imagePath);
    $stmt->bindParam(':project_id', $project_id);
    $stmt->bindParam(':user_id', $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        // Project details updated successfully
        // Redirect the user to the project details page or display a success message
        header("Location: /user_dashboard");
        exit();
    } else {
        // Failed to update project details
        // Handle the error accordingly
        echo "Failed to update project details.";
    }
} else {
    // Redirect the user to the edit project page if the form is not submitted
    header("Location: /edit-project.php?project_id=" . $_POST['project_id']);
    exit();
}
?>
