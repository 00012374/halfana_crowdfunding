    <div class="container">
        <div class="alert alert-success mt-3" role="alert">
            <h4 class="alert-heading">Payment Successful!</h4>
            <p>Your payment has been successfully processed. Thank you for your support!</p>
        </div>
    </div>