<?php
session_start();
// Include necessary files and configurations
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');

// Check if project ID is provided
if (isset($_GET['project_id'])) {
    $project_id = $_GET['project_id'];

    // Fetch project details from the database
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE project_id = ?");
    $stmt->execute([$project_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if project exists
    if ($project) {
        // Display the support project form
        // Retrieve amount from the form data
$amount = $_POST['amount'];

// Convert amount to cents (as an integer)
$amount_in_cents = intval($amount * 100);
?>
        <div class="container">
            <h2>Support Our Project</h2>
            <form id="payment-form" method="post" action="/payment_process"> <!-- Corrected action URL -->
                <input type="hidden" name="project_id" value="<?php echo $project['project_id']; ?>">
                <div class="form-group">
                    <label for="amount">Donation Amount ($)</label>
                    <input type="number" id="amount" name="amount" min="1" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="card-number">Card Number</label>
                    <div id="card-element"></div>
                </div>
                <div id="card-errors" role="alert"></div>
                <input type="hidden" name="stripeToken" id="stripeToken"> <!-- Add a hidden input field for the token -->
                <button type="submit" class="btn btn-primary">Submit Payment</button>
            </form>
        </div>
        <!-- Add Stripe.js library -->
        <script src="https://js.stripe.com/v3/"></script>
        <script>
            var stripe = Stripe('pk_test_51OzVIDHvIAytjv5hCzV7YJgopu0xHETrDfjyuhErNpVT6LMN7KM4tFSPJwNMfuOsMxG490sNDDP4mpTGo4642wO300OGo3oz1L'); // Replace 'YOUR_PUBLIC_KEY' with your actual Stripe publishable key
            var elements = stripe.elements();

            // Create card element
            var cardElement = elements.create('card');
            cardElement.mount('#card-element');

            // Handle real-time validation errors
            cardElement.addEventListener('change', function(event) {
                var displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });

            
            // Handle form submission
            var form = document.getElementById('payment-form');
            form.addEventListener('submit', function(event) {
                event.preventDefault(); // Prevent default form submission
                var amount = parseFloat(document.getElementById('amount').value) * 100; // Convert amount to cents
                stripe.createToken(cardElement).then(function(result) {
                    if (result.error) {
                        var errorElement = document.getElementById('card-errors');
                        errorElement.textContent = result.error.message;
                    } else {
                        // Token created, set the value of the hidden input field
                        document.getElementById('stripeToken').value = result.token.id;
                        // Submit the form
                        form.submit(); // Submit the form with the token
                    }
                });
            });
        </script>
        </body>
        </html>
<?php
    } else {
        echo "Project not found.";
    }
} else {
    echo "Project ID not provided.";
}
?>
