<?php include('../common/header.php'); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-8">
            <h2>Welcome to Admin Panel</h2>
            <!-- Add admin controls, statistics, etc. -->
        </div>
        <div class="col-md-4">
            <h3>Admin Controls</h3>
            <!-- Add admin controls here -->
        </div>
    </div>
</div>

