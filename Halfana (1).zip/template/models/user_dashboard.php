<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Include necessary files and configurations
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');

// Define $projects variable as an empty array
$projects = [];

try {
    // Check if user is logged in
    if (!isset($_SESSION['username'])) {
        // Redirect to login page if user is not logged in
        header("Location: /login");
        exit();
    }

    // Fetch user's projects with image paths and category names
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT p.*, c.category_name 
                           FROM projects p
                           LEFT JOIN categories c ON p.category_id = c.category_id
                           WHERE user_id = ?");
    $stmt->execute([$user_id]);

    // Fetch user's projects
    $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Log the exception message
    error_log('Exception: ' . $e->getMessage());
    // Print a generic error message for the user
    echo 'An unexpected error occurred. Please try again later.';
}
?>



    <div class="container mt-5">
        <h2>User Dashboard</h2> <a href="add-project">add project</a>
        <div class="row">
            <?php foreach ($projects as $project): ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <!-- Display project image -->
                            <?php if (!empty($project['image_path'])): ?>
                                <img src="<?php echo htmlspecialchars($project['image_path']); ?>" class="card-img-top" alt="Project Image">
                            <?php else: ?>
                                <img src="/uploads/placeholder-image.jpg" class="card-img-top" alt="Placeholder Image">
                            <?php endif; ?>
                            <h5 class="card-title"><?php echo htmlspecialchars($project['title'] ?? 'Title not available'); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($project['description'] ?? 'Description not available'); ?></p>
                            <p class="card-text">Category: <?php echo htmlspecialchars($project['category_name'] ?? 'Uncategorized'); ?></p>
                            <p class="card-text">Funding Goal: $<?php echo isset($project['funding_goal']) ? number_format($project['funding_goal'], 2) : 'Goal not set'; ?></p>
                            <p class="card-text">Current Funding: $<?php echo isset($project['funding_current']) ? number_format($project['funding_current'], 2) : 'Current funding not available'; ?></p>
                            <p class="card-text">Deadline: <?php echo htmlspecialchars($project['deadline'] ?? 'Deadline not set'); ?></p>
                            <!-- Edit and delete buttons -->
                            <div class="btn-group" role="group" aria-label="Project Actions">
                                <a href="edit-project?project_id=<?php echo $project['project_id']; ?>" class="btn btn-primary">Edit</a>
                                <a href="delete-project-process?id=<?php echo $project['project_id']; ?>" class="btn btn-danger">Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <!-- Include pagination -->
    <?php include($_SERVER['DOCUMENT_ROOT'] . '/template/common/pagination.php'); ?>

