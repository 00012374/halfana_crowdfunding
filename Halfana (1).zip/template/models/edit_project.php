<?php
session_start();
// Include necessary files and configurations
include($_SERVER['DOCUMENT_ROOT'] . '/database/db_config.php');

// Check if project ID and user ID are provided
if (isset($_GET['project_id']) && isset($_SESSION['user_id'])) {
    $project_id = $_GET['project_id'];
    $user_id = $_SESSION['user_id'];

    // Fetch project details from the database
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE project_id = ? AND user_id = ?");
    $stmt->execute([$project_id, $user_id]);
    $project = $stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch categories from the database
    $stmt_categories = $pdo->query("SELECT * FROM categories");
    $categories = $stmt_categories->fetchAll(PDO::FETCH_ASSOC);

    // Check if project exists and belongs to the current user
    if ($project) {
        // Display the edit project form
        ?>
        <h2>Edit Project</h2>
        <form method="post" action="/edit-project-process" enctype="multipart/form-data">
            <input type="hidden" name="project_id" value="<?php echo $project['project_id']; ?>">
            <label for="title">Title:</label><br>
            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($project['title']); ?>"><br>
            <label for="description">Description:</label><br>
            <textarea id="description" name="description"><?php echo htmlspecialchars($project['description']); ?></textarea><br>
            <label for="funding_goal">Funding Goal:</label><br>
            <input type="text" id="funding_goal" name="funding_goal" value="<?php echo $project['funding_goal']; ?>"><br>
            <label for="deadline">Deadline:</label><br>
            <input type="date" id="deadline" name="deadline" value="<?php echo $project['deadline']; ?>"><br>
            <!-- Add category selection -->
            <label for="category">Category:</label><br>
            <select id="category" name="category">
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['category_id']; ?>" <?php echo ($category['category_id'] == $project['category_id']) ? 'selected' : ''; ?>><?php echo $category['category_name']; ?></option>
                <?php endforeach; ?>
            </select><br>
            <!-- Add file input field for project image editing -->
            <label for="projectImage">Project Image:</label>
            <input type="file" class="form-control-file" id="projectImage" name="projectImage"><br>
            <button type="submit" class="btn btn-primary">Update Project</button>
        </form>
        </body>
        </html>
        <?php
    } else {
        echo "Project not found or does not belong to the current user.";
    }
} else {
    echo "Project ID or user ID not provided.";
}
?>
