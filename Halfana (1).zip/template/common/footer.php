<!-- Contact and Support Section -->
<footer>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <h5>Contact Us</h5>
                <p>Phone: +998 71 200 9777</p>
                <p>Email: halfana@info.com</p>
            </div>
            <div class="col-md-6 text-right">
                <a href="#" class="btn btn-success">Support a Project</a>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS and jQuery -->
<!-- <script scr="../assets/js/ajax.js" type="text/javascript"></script> -->
<script scr="/template/assets/js/main.js" type="text/javascript"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
