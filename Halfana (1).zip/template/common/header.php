<?php
session_start(); // Start the session
$isHomepage = ($_SERVER['REQUEST_URI'] == '/' || $_SERVER['REQUEST_URI'] == '/index.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Halfana Crowdfunding Platform</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="/template/assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://js.stripe.com/v3/"></script>
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="/">Halfana</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <?php if (isset($_SESSION['username'])) : ?>
                    <!-- User is logged in -->
                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="user_dashboard">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/user_dashboard">Profile (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout">Logout</a></li>
                <?php else : ?>
                    <!-- User is not logged in -->
                    <li class="nav-item"><a class="nav-link" href="/">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="login">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="register">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<?php if ($isHomepage) : ?>
    <!-- Header Slider -->
    <div id="header-slider" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="template/assets/images/slider_image1.jpg" class="d-block w-100" alt="Slider Image 1">
                <div class="carousel-caption">
                    <h3>Project Title 1</h3>
                    <p>Subtitle or project description goes here.</p>
                </div>
            </div>
            <!-- Add more carousel items as needed -->
        </div>
    </div>
<?php endif; ?>
