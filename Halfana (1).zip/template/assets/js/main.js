// JavaScript for carousel navigation
$('.carousel-control-next').click(function() {
    $('#projectCarousel').carousel('next');
});

$('.carousel-control-prev').click(function() {
    $('#projectCarousel').carousel('prev');
});
function(e) {
        let $nextItem = $(e.relatedTarget);
        let index = $nextItem.index();
        let numItems = $nextItem.siblings().length + 1;
        let newSlidePosition = Math.floor(index / 3);

        // Scroll to the new slide position
        $('#projectCarousel').carousel(newSlidePosition);
    });
});
